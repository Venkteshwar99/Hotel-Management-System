package com.Reservation.Models;

import java.util.List;

public class ReservationList {
	
	private List<Reservation> resList;

	public List<Reservation> getResList() {
		return resList;
	}

	public void setResList(List<Reservation> resList) {
		this.resList = resList;
	}

}

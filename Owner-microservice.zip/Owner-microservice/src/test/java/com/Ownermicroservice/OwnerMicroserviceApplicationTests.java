package com.Ownermicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OwnerMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
